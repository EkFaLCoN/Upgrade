package net.mrwqlf.upgrade;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

/**
 * Efsanevi scroll ile yukseltilebilen, yonetici tarafindan KAYDEDILMIS ozel esyalar.
 * Esya kimligi: tur + item_model + yabanci PDC verileri + (ilk) ad.
 * Yukseltme ad/lore/seviye degistirdigi icin bunlar kimliga katilmaz.
 */
public final class Kayit {

    public static final int MAKS = 45;

    public record Giris(String imza, ItemStack gosterim) {
    }

    private final UpgradeSistemi eklenti;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final File dosya;
    private final List<Giris> girisler = new ArrayList<>();

    public Kayit(UpgradeSistemi eklenti) {
        this.eklenti = eklenti;
        this.dosya = new File(eklenti.getDataFolder(), "kayit.yml");
    }

    public List<Giris> liste() {
        return girisler;
    }

    private static Object deger(PersistentDataContainer p, NamespacedKey k) {
        if (p.has(k, PersistentDataType.STRING)) {
            return p.get(k, PersistentDataType.STRING);
        }
        if (p.has(k, PersistentDataType.INTEGER)) {
            return p.get(k, PersistentDataType.INTEGER);
        }
        if (p.has(k, PersistentDataType.LONG)) {
            return p.get(k, PersistentDataType.LONG);
        }
        if (p.has(k, PersistentDataType.DOUBLE)) {
            return p.get(k, PersistentDataType.DOUBLE);
        }
        if (p.has(k, PersistentDataType.BYTE)) {
            return p.get(k, PersistentDataType.BYTE);
        }
        if (p.has(k, PersistentDataType.SHORT)) {
            return p.get(k, PersistentDataType.SHORT);
        }
        if (p.has(k, PersistentDataType.FLOAT)) {
            return p.get(k, PersistentDataType.FLOAT);
        }
        return "?";
    }

    private boolean bizim(NamespacedKey k) {
        return k.getNamespace().equalsIgnoreCase(eklenti.getName());
    }

    /** Ozel esya mi? (item_model, custom model data veya baska eklentinin PDC verisi var). */
    public boolean ozelMi(ItemStack e) {
        if (e == null || !e.hasItemMeta()) {
            return false;
        }
        ItemMeta m = e.getItemMeta();
        if (m.hasItemModel() || m.hasCustomModelDataComponent()) {
            return true;
        }
        for (NamespacedKey k : m.getPersistentDataContainer().getKeys()) {
            if (!bizim(k)) {
                return true;
            }
        }
        return false;
    }

    public String imza(ItemStack e) {
        StringBuilder sb = new StringBuilder(e.getType().name());
        String ad = null;
        if (e.hasItemMeta()) {
            ItemMeta m = e.getItemMeta();
            PersistentDataContainer p = m.getPersistentDataContainer();
            if (m.hasItemModel()) {
                sb.append("|model=").append(m.getItemModel());
            }
            TreeMap<String, String> pdc = new TreeMap<>();
            for (NamespacedKey k : p.getKeys()) {
                if (bizim(k)) {
                    continue;
                }
                pdc.put(k.toString(), String.valueOf(deger(p, k)));
            }
            sb.append("|pdc=").append(pdc);
            ad = p.get(new NamespacedKey(eklenti, "upg_ad"), PersistentDataType.STRING);
        }
        if (ad == null) {
            ad = mm.serialize(e.effectiveName());
        }
        return sb.append("|ad=").append(ad).toString().toLowerCase(Locale.ROOT);
    }

    public boolean kayitli(ItemStack e) {
        String s = imza(e);
        for (Giris g : girisler) {
            if (g.imza().equals(s)) {
                return true;
            }
        }
        return false;
    }

    /** true -> eklendi; false -> zaten kayitli veya dolu. */
    public boolean ekle(ItemStack e) {
        if (kayitli(e) || girisler.size() >= MAKS) {
            return false;
        }
        ItemStack k = e.clone();
        k.setAmount(1);
        girisler.add(new Giris(imza(e), k));
        kaydet();
        return true;
    }

    public void sil(int index) {
        if (index >= 0 && index < girisler.size()) {
            girisler.remove(index);
            kaydet();
        }
    }

    public void yukle() {
        girisler.clear();
        if (!dosya.exists()) {
            return;
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dosya);
        ConfigurationSection kok = y.getConfigurationSection("kayitlar");
        if (kok == null) {
            return;
        }
        for (String anahtar : kok.getKeys(false)) {
            try {
                ItemStack e = ItemStack.deserializeBytes(Base64.getDecoder().decode(kok.getString(anahtar + ".esya", "")));
                girisler.add(new Giris(kok.getString(anahtar + ".imza", imza(e)), e));
            } catch (Exception ex) {
                eklenti.getLogger().warning("Kayit okunamadi (" + anahtar + "): " + ex.getMessage());
            }
        }
    }

    public void kaydet() {
        YamlConfiguration y = new YamlConfiguration();
        int i = 0;
        for (Giris g : girisler) {
            y.set("kayitlar." + i + ".imza", g.imza());
            y.set("kayitlar." + i + ".esya", Base64.getEncoder().encodeToString(g.gosterim().serializeAsBytes()));
            i++;
        }
        try {
            eklenti.getDataFolder().mkdirs();
            File gecici = new File(eklenti.getDataFolder(), "kayit.yml.tmp");
            y.save(gecici);
            Files.move(gecici.toPath(), dosya.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            eklenti.getLogger().severe("kayit.yml kaydedilemedi: " + ex.getMessage());
        }
    }
}
