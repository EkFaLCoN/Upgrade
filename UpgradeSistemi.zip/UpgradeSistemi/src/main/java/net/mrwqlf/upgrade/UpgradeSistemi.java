package net.mrwqlf.upgrade;

import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/** UpgradeSistemi - silah/zirh +10 yukseltme. Tek komut: /upgrade (yalnizca yonetici katalogu). */
public final class UpgradeSistemi extends JavaPlugin {

    private Esyalar esyalar;
    private Seviye seviye;
    private Tema tema;
    private AdminMenu adminMenu;
    private Kayit kayit;
    private final Ekonomi ekonomi = new Ekonomi();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.esyalar = new Esyalar(this);
        this.seviye = new Seviye(this);
        this.tema = new Tema(this);
        this.kayit = new Kayit(this);
        this.kayit.yukle();
        this.adminMenu = new AdminMenu(this);
        getServer().getPluginManager().registerEvents(new Dinleyici(this), this);
        getServer().getScheduler().runTaskTimer(this, new Aura(this, seviye, tema), 40L, 4L);

        var komut = getCommand("upgrade");
        if (komut != null) {
            CommandExecutor yurutucu = (g, k, e, a) -> {
                if (!(g instanceof Player oyuncu)) {
                    g.sendMessage("Bu komut yalnizca oyunculara ozeldir.");
                    return true;
                }
                if (!oyuncu.hasPermission("upgrade.admin")) {
                    oyuncu.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                            .deserialize(getConfig().getString("mesajlar.yetkin-yok", "")));
                    return true;
                }
                adminMenu.ac(oyuncu);
                return true;
            };
            komut.setExecutor(yurutucu);
            komut.setTabCompleter((TabCompleter) (g, k, e, a) -> List.of());
        }
    }

    public Esyalar esyalar() {
        return esyalar;
    }

    public Seviye seviye() {
        return seviye;
    }

    public Kayit kayit() {
        return kayit;
    }

    public Ekonomi ekonomi() {
        return ekonomi;
    }

    public AdminMenu adminMenu() {
        return adminMenu;
    }
}
