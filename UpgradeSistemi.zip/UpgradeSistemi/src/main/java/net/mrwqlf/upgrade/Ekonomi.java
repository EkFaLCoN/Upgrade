package net.mrwqlf.upgrade;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Ekonomi koprusu (derleme icin bagimlilik gerekmez, hepsi yansima ile):
 *  1) Vault ekonomisi varsa onu kullanir,
 *  2) yoksa MarketAH eklentisinin kendi para sistemini arar (bakiye / cek / yatir yontemleri).
 * Hangi yontemlerin secildigi acilista konsola yazilir.
 */
public final class Ekonomi {

    private static final String[] BAKIYE = {"getBalance", "bakiye", "getBakiye", "balance", "getMoney", "getPara", "para", "get"};
    private static final String[] CEK = {"paraCek", "withdraw", "withdrawPlayer", "cek", "paraCek", "removeBalance", "removeMoney", "takeMoney", "take", "remove", "subtract", "azalt"};
    private static final String[] YATIR = {"paraEkle", "deposit", "depositPlayer", "yatir", "paraYatir", "addBalance", "addMoney", "giveMoney", "give", "add", "ekle", "artir"};

    // Vault
    private Object saglayici;
    private Method vBakiye, vCek, vYatir, vBasarili;
    // MarketAH
    private Object hedef;
    private Method mBakiye, mCek, mYatir;
    private Class<?> bakiyeParam, cekParam, yatirParam;
    private boolean mod;   // true: Vault, false: MarketAH
    private boolean bagli;
    private long sonDeneme;

    private boolean bagla() {
        if (bagli) {
            return true;
        }
        long simdi = System.currentTimeMillis();
        if (simdi - sonDeneme < 3000L) {
            return false;
        }
        sonDeneme = simdi;
        return vaultBagla() || marketBagla();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private boolean vaultBagla() {
        try {
            Class<?> ekoSinif = Class.forName("net.milkbowl.vault.economy.Economy");
            RegisteredServiceProvider rsp = Bukkit.getServicesManager().getRegistration((Class) ekoSinif);
            if (rsp == null) {
                return false;
            }
            Object s = rsp.getProvider();
            Method b = ekoSinif.getMethod("getBalance", OfflinePlayer.class);
            Method c = ekoSinif.getMethod("withdrawPlayer", OfflinePlayer.class, double.class);
            Method y = ekoSinif.getMethod("depositPlayer", OfflinePlayer.class, double.class);
            Method ok = Class.forName("net.milkbowl.vault.economy.EconomyResponse").getMethod("transactionSuccess");
            this.saglayici = s;
            this.vBakiye = b;
            this.vCek = c;
            this.vYatir = y;
            this.vBasarili = ok;
            this.mod = true;
            this.bagli = true;
            Bukkit.getLogger().info("[Ekonomi] Vault ekonomisine baglandi.");
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean marketBagla() {
        try {
            Plugin pl = Bukkit.getPluginManager().getPlugin("MarketAH");
            if (pl == null || !pl.isEnabled()) {
                return false;
            }
            List<Object> adaylar = new ArrayList<>();
            adaylar.add(pl);
            for (Method m : pl.getClass().getMethods()) {
                if (m.getParameterCount() != 0 || m.getReturnType().isPrimitive()
                        || m.getReturnType() == String.class || m.getDeclaringClass() == Object.class
                        || Modifier.isStatic(m.getModifiers())) {
                    continue;
                }
                String ad = m.getName().toLowerCase(java.util.Locale.ROOT);
                if (ad.contains("ekonomi") || ad.contains("economy") || ad.contains("para") || ad.contains("bank")
                        || ad.contains("bakiye") || ad.contains("balance") || ad.contains("money")) {
                    Object o = m.invoke(pl);
                    if (o != null) {
                        adaylar.add(o);
                    }
                }
            }
            for (Object o : adaylar) {
                Method b = bul(o.getClass(), BAKIYE, false);
                Method c = bul(o.getClass(), CEK, true);
                Method y = bul(o.getClass(), YATIR, true);
                if (b != null && c != null && y != null) {
                    this.hedef = o;
                    this.mBakiye = b;
                    this.mCek = c;
                    this.mYatir = y;
                    this.mod = false;
                    this.bagli = true;
                    Bukkit.getLogger().info("[Ekonomi] MarketAH para sistemine baglandi: " + o.getClass().getName()
                            + " bakiye=" + b.getName() + " cek=" + c.getName() + " yatir=" + y.getName());
                    return true;
                }
            }
            Bukkit.getLogger().warning("[Ekonomi] MarketAH bulundu ama para yontemleri taninamadi.");
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean oyuncuTipi(Class<?> c) {
        return c == OfflinePlayer.class || c == Player.class || c == UUID.class || c == String.class;
    }

    private static boolean sayiTipi(Class<?> c) {
        return c == double.class || c == long.class || c == int.class || c == Double.class || c == Long.class;
    }

    /** Adi tercih sirasina gore, imzasi (oyuncu) veya (oyuncu, sayi) olan yontemi bulur. */
    private Method bul(Class<?> sinif, String[] adlar, boolean miktarli) {
        for (String ad : adlar) {
            for (Method m : sinif.getMethods()) {
                if (!m.getName().equalsIgnoreCase(ad) || Modifier.isStatic(m.getModifiers())) {
                    continue;
                }
                Class<?>[] p = m.getParameterTypes();
                if (miktarli && p.length == 2 && oyuncuTipi(p[0]) && sayiTipi(p[1])) {
                    return m;
                }
                if (!miktarli && p.length == 1 && oyuncuTipi(p[0]) && !m.getReturnType().equals(void.class)) {
                    return m;
                }
            }
        }
        return null;
    }

    private static Object oyuncuArg(Class<?> tip, OfflinePlayer o) {
        if (tip == UUID.class) {
            return o.getUniqueId();
        }
        if (tip == String.class) {
            return o.getName();
        }
        if (tip == Player.class) {
            return o.getPlayer();
        }
        return o;
    }

    private static Object sayiArg(Class<?> tip, double v) {
        if (tip == long.class || tip == Long.class) {
            return Math.round(v);
        }
        if (tip == int.class) {
            return (int) Math.round(v);
        }
        return v;
    }

    public boolean var() {
        return bagla();
    }

    public double bakiye(OfflinePlayer o) {
        if (!bagla()) {
            return 0;
        }
        try {
            if (mod) {
                return (double) vBakiye.invoke(saglayici, o);
            }
            Object r = mBakiye.invoke(hedef, oyuncuArg(mBakiye.getParameterTypes()[0], o));
            return r instanceof Number n ? n.doubleValue() : 0;
        } catch (Throwable t) {
            return 0;
        }
    }

    public boolean cek(OfflinePlayer o, double miktar) {
        if (!bagla()) {
            return false;
        }
        try {
            if (mod) {
                return (boolean) vBasarili.invoke(vCek.invoke(saglayici, o, miktar));
            }
            if (bakiye(o) < miktar) {
                return false;
            }
            Object r = mCek.invoke(hedef, oyuncuArg(mCek.getParameterTypes()[0], o),
                    sayiArg(mCek.getParameterTypes()[1], miktar));
            return !(r instanceof Boolean b) || b;
        } catch (Throwable t) {
            return false;
        }
    }

    public boolean yatir(OfflinePlayer o, double miktar) {
        if (!bagla()) {
            return false;
        }
        try {
            if (mod) {
                return (boolean) vBasarili.invoke(vYatir.invoke(saglayici, o, miktar));
            }
            Object r = mYatir.invoke(hedef, oyuncuArg(mYatir.getParameterTypes()[0], o),
                    sayiArg(mYatir.getParameterTypes()[1], miktar));
            return !(r instanceof Boolean b) || b;
        } catch (Throwable t) {
            return false;
        }
    }
}
