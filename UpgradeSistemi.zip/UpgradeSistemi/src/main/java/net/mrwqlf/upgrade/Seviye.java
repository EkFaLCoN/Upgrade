package net.mrwqlf.upgrade;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/** Esya seviyesi (+0..+10): okuma/yazma, ad-lore-parlama guncelleme, kademe hesabi. */
public final class Seviye {

    public static final int MAKS = 10;

    private final UpgradeSistemi eklenti;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final NamespacedKey lvl, arcana, ad, loreN;

    public Seviye(UpgradeSistemi eklenti) {
        this.eklenti = eklenti;
        this.lvl = new NamespacedKey(eklenti, "upg_seviye");
        this.arcana = new NamespacedKey(eklenti, "upg_arcana");
        this.ad = new NamespacedKey(eklenti, "upg_ad");
        this.loreN = new NamespacedKey(eklenti, "upg_lore_n");
    }

    // ---------------------------------------------------------- sinif
    public static boolean silahMi(ItemStack e) {
        if (e == null) {
            return false;
        }
        String n = e.getType().name();
        return n.endsWith("_SWORD") || n.endsWith("_AXE") || n.endsWith("_SPEAR")
                || e.getType() == Material.BOW || e.getType() == Material.CROSSBOW
                || e.getType() == Material.TRIDENT || e.getType() == Material.MACE;
    }

    public static boolean zirhMi(ItemStack e) {
        if (e == null) {
            return false;
        }
        String n = e.getType().name();
        return n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE") || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS");
    }

    /** Esyanin gucune gore scroll kademesi: 1 zayif, 2 guclu, 3 efsanevi. */
    public static int kademe(ItemStack e) {
        Material m = e.getType();
        String n = m.name();
        if (m == Material.TRIDENT || m == Material.MACE || n.startsWith("DIAMOND") || n.startsWith("NETHERITE")) {
            return 3;
        }
        if (n.startsWith("IRON") || n.startsWith("TURTLE") || m == Material.BOW || m == Material.CROSSBOW) {
            return 2;
        }
        return 1;
    }

    // ---------------------------------------------------------- okuma
    public int seviye(ItemStack e) {
        if (e == null || !e.hasItemMeta()) {
            return 0;
        }
        Integer v = e.getItemMeta().getPersistentDataContainer().get(lvl, PersistentDataType.INTEGER);
        return v == null ? 0 : Math.max(0, Math.min(MAKS, v));
    }

    public boolean arcanaVar(ItemStack e) {
        return e != null && e.hasItemMeta()
                && e.getItemMeta().getPersistentDataContainer().has(arcana, PersistentDataType.BYTE);
    }

    // ---------------------------------------------------------- hesap
    public double sans(int hedef) {
        return eklenti.getConfig().getDouble("sans." + hedef, 0);
    }

    public double kirilma(int hedef) {
        return eklenti.getConfig().getDouble("kirilma." + hedef, 0);
    }

    public int shardGerek(int hedef) {
        return eklenti.getConfig().getInt("shard." + hedef, 0);
    }

    /** +7'ye kadar seviye basina normal bonus, +7'den sonraki her seviye icin daha guclu bonus. */
    public double silahBonus(int seviye) {
        var c = eklenti.getConfig();
        int alt = Math.min(seviye, 7);
        int ust = Math.max(0, seviye - 7);
        return alt * c.getDouble("silah-hasar-bonusu", 0.04) + ust * c.getDouble("silah-hasar-bonusu-7-ustu", 0.10);
    }

    public double zirhAzaltma(int seviye) {
        var c = eklenti.getConfig();
        int alt = Math.min(seviye, 7);
        int ust = Math.max(0, seviye - 7);
        return alt * c.getDouble("zirh-hasar-azaltma", 0.0075) + ust * c.getDouble("zirh-hasar-azaltma-7-ustu", 0.02);
    }

    // ---------------------------------------------------------- yazma
    /** Seviye ve arcana bayragini uygular; ad, lore ve parlamayi gunceller. */
    public void uygula(ItemStack e, int seviye, boolean arcanaVarMi) {
        ItemMeta meta = e.getItemMeta();
        PersistentDataContainer p = meta.getPersistentDataContainer();

        // Orijinal adi bir kez sakla
        if (!p.has(ad, PersistentDataType.STRING)) {
            p.set(ad, PersistentDataType.STRING, mm.serialize(e.effectiveName()));
        }
        String taban = p.get(ad, PersistentDataType.STRING);

        p.set(lvl, PersistentDataType.INTEGER, seviye);
        if (arcanaVarMi) {
            p.set(arcana, PersistentDataType.BYTE, (byte) 1);
        } else {
            p.remove(arcana);
        }

        // Ad
        String renk = renk(seviye);
        Component govde = mm.deserialize("<!italic>" + taban).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false);
        if (seviye > 0) {
            Component onEk = mm.deserialize("<!italic>" + renk + "+" + seviye + " ");
            meta.displayName(Component.empty().append(onEk).append(govde));
        } else {
            meta.displayName(govde);
        }

        // Lore: onceki satirlarimizi sil, yenilerini ekle
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        Integer eski = p.get(loreN, PersistentDataType.INTEGER);
        if (eski != null) {
            for (int i = 0; i < eski && !lore.isEmpty(); i++) {
                lore.remove(lore.size() - 1);
            }
        }
        List<Component> yeni = new ArrayList<>();
        yeni.add(Component.empty());
        if (seviye > 0) {
            yeni.add(mm.deserialize("<!italic><gray>Yükseltme: " + renk + "+" + seviye));
        }
        if (seviye == 0) {
            // bonus satiri yok
        } else if (silahMi(e)) {
            yeni.add(mm.deserialize("<!italic><gray>Hasar bonusu: <green>+" + Math.round(silahBonus(seviye) * 100) + "%"));
        } else {
            yeni.add(mm.deserialize("<!italic><gray>Hasar azaltma: <green>-"
                    + String.format(java.util.Locale.ROOT, "%.1f", zirhAzaltma(seviye) * 100) + "%"));
        }
        if (seviye >= 7) {
            yeni.add(mm.deserialize("<!italic><aqua>✦ Parlıyor"));
        }
        if (arcanaVarMi) {
            yeni.add(mm.deserialize("<!italic><light_purple>✦ Arcana: sonraki şans artışı"));
        }
        lore.addAll(yeni);
        meta.lore(lore);
        p.set(loreN, PersistentDataType.INTEGER, yeni.size());

        // +7 ve sonrasi parlama
        meta.setEnchantmentGlintOverride(seviye >= 7 ? Boolean.TRUE : null);
        e.setItemMeta(meta);
    }

    private String renk(int s) {
        if (s >= 10) {
            return "<gold><bold>";
        }
        if (s >= 7) {
            return "<aqua>";
        }
        if (s >= 4) {
            return "<green>";
        }
        return "<white>";
    }

    public FileConfiguration cfg() {
        return eklenti.getConfig();
    }
}
