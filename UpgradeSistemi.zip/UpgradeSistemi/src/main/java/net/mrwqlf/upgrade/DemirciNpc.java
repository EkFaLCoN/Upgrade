package net.mrwqlf.upgrade;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;

/** Demirci NPC'si: AI'siz, olumsuz silah-demircisi koylu. Komutsuz; yonetici katalogundan olusturulur. */
public final class DemirciNpc {

    private final UpgradeSistemi eklenti;
    private final NamespacedKey anahtar;

    public DemirciNpc(UpgradeSistemi eklenti) {
        this.eklenti = eklenti;
        this.anahtar = new NamespacedKey(eklenti, "demirci_npc");
    }

    public boolean npcMi(Entity e) {
        return e != null && e.getPersistentDataContainer().has(anahtar, PersistentDataType.BYTE);
    }

    public void olustur(Player p) {
        if (!p.hasPermission("upgrade.admin")) {
            return;
        }
        Location yer = p.getLocation();
        Villager npc = p.getWorld().spawn(yer, Villager.class, v -> {
            v.setAI(false);
            v.setInvulnerable(true);
            v.setSilent(true);
            v.setPersistent(true);
            v.setRemoveWhenFarAway(false);
            v.setCollidable(false);
            v.setProfession(Villager.Profession.WEAPONSMITH);
            v.setVillagerType(Villager.Type.PLAINS);
            v.customName(MiniMessage.miniMessage().deserialize("<gold><bold>Demirci"));
            v.setCustomNameVisible(true);
            v.getPersistentDataContainer().set(anahtar, PersistentDataType.BYTE, (byte) 1);
        });
        npc.setRotation(yer.getYaw() + 180f, 0f);
        p.sendMessage(MiniMessage.miniMessage().deserialize(
                eklenti.getConfig().getString("mesajlar.npc-olusturuldu", "")));
    }

    public void kaldir(Player p, Entity e) {
        if (!p.hasPermission("upgrade.admin") || !npcMi(e)) {
            return;
        }
        e.remove();
        p.sendMessage(MiniMessage.miniMessage().deserialize(
                eklenti.getConfig().getString("mesajlar.npc-silindi", "")));
    }

    /** Yuklu tum dunyalardaki demirci NPC'lerini kaldirir (yalnizca yonetici). */
    public int tumunuKaldir(Player p) {
        if (!p.hasPermission("upgrade.admin")) {
            return 0;
        }
        int n = 0;
        for (org.bukkit.World w : org.bukkit.Bukkit.getWorlds()) {
            for (Villager v : w.getEntitiesByClass(Villager.class)) {
                if (npcMi(v)) {
                    v.remove();
                    n++;
                }
            }
        }
        return n;
    }
}
