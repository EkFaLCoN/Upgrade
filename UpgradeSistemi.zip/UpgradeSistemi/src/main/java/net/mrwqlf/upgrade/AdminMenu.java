package net.mrwqlf.upgrade;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * /upgrade (yalnizca upgrade.admin):
 *  - KATALOG: scroll / arcana / shard al (sol tik 1, shift+sol 16) + "Efsanevi esya kaydi" dugmesi
 *  - KAYIT : kayitli ozel esyalar. Kendi envanterindeki silah/zirha tikla = kaydet; kayitliya shift+tik = sil.
 * Tum tiklamalar iptal edilir; yetki her tiklamada tekrar kontrol edilir.
 */
public final class AdminMenu {

    enum Tur { KATALOG, KAYIT }

    static final class Tutucu implements InventoryHolder {
        Inventory envanter;
        Tur tur = Tur.KATALOG;

        @Override
        public Inventory getInventory() {
            return envanter;
        }
    }

    static final String[] SIRA = {"scroll_1", "scroll_2", "scroll_3", "arcana",
            "shard_weapon_g", "shard_armor_g", "shard_weapon_e", "shard_armor_e"};
    static final int[] SLOT = {10, 11, 12, 14, 19, 20, 24, 25};
    static final int KAYIT_DUGME = 40;

    private final UpgradeSistemi eklenti;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public AdminMenu(UpgradeSistemi eklenti) {
        this.eklenti = eklenti;
    }

    private ItemStack dugme(Material m, String ad, String... lore) {
        ItemStack e = new ItemStack(m);
        var meta = e.getItemMeta();
        meta.displayName(mm.deserialize("<!italic>" + ad));
        List<Component> l = new ArrayList<>();
        for (String s : lore) {
            l.add(mm.deserialize("<!italic>" + s));
        }
        meta.lore(l);
        e.setItemMeta(meta);
        return e;
    }

    private ItemStack dolgu() {
        ItemStack d = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        var meta = d.getItemMeta();
        meta.displayName(Component.empty());
        d.setItemMeta(meta);
        return d;
    }

    public void ac(Player p) {
        Tutucu t = new Tutucu();
        t.envanter = Bukkit.createInventory(t, 45, mm.deserialize("<dark_gray>Upgrade katalog"));
        katalogCiz(t);
        p.openInventory(t.envanter);
    }

    private void kayitAc(Player p) {
        Tutucu t = new Tutucu();
        t.tur = Tur.KAYIT;
        t.envanter = Bukkit.createInventory(t, 54, mm.deserialize("<gold>Efsanevi eşya kaydı"));
        kayitCiz(t);
        p.openInventory(t.envanter);
    }

    private void katalogCiz(Tutucu t) {
        Inventory env = t.envanter;
        for (int i = 0; i < env.getSize(); i++) {
            env.setItem(i, dolgu());
        }
        for (int i = 0; i < SIRA.length; i++) {
            env.setItem(SLOT[i], eklenti.esyalar().uret(SIRA[i], 1));
        }
        env.setItem(KAYIT_DUGME, dugme(Material.WRITABLE_BOOK, "<gold>Efsanevi eşya kaydı",
                "<gray>Efsanevi scroll ile yükseltilecek", "<gray>özel eşyaları buradan kaydet."));
    }

    private void kayitCiz(Tutucu t) {
        Inventory env = t.envanter;
        env.clear();
        List<Kayit.Giris> liste = eklenti.kayit().liste();
        for (int i = 0; i < Kayit.MAKS && i < liste.size(); i++) {
            ItemStack e = liste.get(i).gosterim().clone();
            var meta = e.getItemMeta();
            List<Component> lore = new ArrayList<>(meta.lore() == null ? List.of() : meta.lore());
            lore.add(Component.empty());
            lore.add(mm.deserialize("<!italic><red>Shift+tık: kaydı sil"));
            meta.lore(lore);
            e.setItemMeta(meta);
            env.setItem(i, e);
        }
        for (int i = 45; i < 54; i++) {
            env.setItem(i, dolgu());
        }
        env.setItem(45, dugme(Material.ARROW, "<yellow>◀ Geri"));
        env.setItem(49, dugme(Material.PAPER, "<white>Kayıtlı eşya: <yellow>" + liste.size() + "<gray>/" + Kayit.MAKS,
                "<gray>Kaydetmek için <white>kendi envanterindeki",
                "<gray>silah/zırha tıkla.", "<gray>Silmek için kayıtlıya <white>Shift+tık<gray>."));
    }

    void tikla(Player p, Tutucu t, boolean ust, int slot, ItemStack tiklanan, ClickType tur) {
        if (!p.hasPermission("upgrade.admin")) {
            p.closeInventory();
            return;
        }
        if (t.tur == Tur.KATALOG) {
            if (!ust) {
                return;
            }
            if (slot == KAYIT_DUGME) {
                kayitAc(p);
                return;
            }
            for (int i = 0; i < SLOT.length; i++) {
                if (SLOT[i] == slot) {
                    ItemStack e = eklenti.esyalar().uret(SIRA[i], tur == ClickType.SHIFT_LEFT ? 16 : 1);
                    for (ItemStack artan : p.getInventory().addItem(e).values()) {
                        p.getWorld().dropItemNaturally(p.getLocation(), artan);
                    }
                    return;
                }
            }
            return;
        }
        // KAYIT ekrani
        if (!ust) {
            if (tiklanan == null || tiklanan.getType().isAir()) {
                return;
            }
            if (!Seviye.silahMi(tiklanan) && !Seviye.zirhMi(tiklanan)) {
                p.sendMessage(mm.deserialize(eklenti.getConfig().getString("mesajlar.kayit-gecersiz", "")));
                return;
            }
            boolean eklendi = eklenti.kayit().ekle(tiklanan);
            p.sendMessage(mm.deserialize(eklenti.getConfig().getString(
                    eklendi ? "mesajlar.kayit-eklendi" : "mesajlar.kayit-zaten", "")));
            kayitCiz(t);
            return;
        }
        if (slot == 45) {
            ac(p);
            return;
        }
        if (slot >= 0 && slot < Kayit.MAKS && tur.isShiftClick() && slot < eklenti.kayit().liste().size()) {
            eklenti.kayit().sil(slot);
            p.sendMessage(mm.deserialize(eklenti.getConfig().getString("mesajlar.kayit-silindi", "")));
            kayitCiz(t);
        }
    }
}
