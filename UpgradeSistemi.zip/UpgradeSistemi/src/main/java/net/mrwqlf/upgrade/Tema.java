package net.mrwqlf.upgrade;

import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Color;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Locale;

/** Parlama rengi: esyanin temasina gore (sinif, ruby, buz, alev..., yoksa materyal). */
public final class Tema {

    private final UpgradeSistemi eklenti;
    private final NamespacedKey dbdId = new NamespacedKey("dropbydrop", "dbd_id");

    public Tema(UpgradeSistemi eklenti) {
        this.eklenti = eklenti;
    }

    private static String sadelestir(String s) {
        return s.toLowerCase(Locale.ROOT)
                .replace('ı', 'i').replace('ş', 's').replace('ğ', 'g')
                .replace('ü', 'u').replace('ö', 'o').replace('ç', 'c');
    }

    public Color renk(ItemStack e) {
        StringBuilder sb = new StringBuilder(e.getType().name());
        if (e.hasItemMeta()) {
            ItemMeta m = e.getItemMeta();
            String id = m.getPersistentDataContainer().get(dbdId, PersistentDataType.STRING);
            if (id != null) {
                sb.append(' ').append(id);
            }
            if (m.hasItemModel()) {
                sb.append(' ').append(m.getItemModel());
            }
        }
        sb.append(' ').append(PlainTextComponentSerializer.plainText().serialize(e.effectiveName()));
        String metin = sadelestir(sb.toString());

        ConfigurationSection s = eklenti.getConfig().getConfigurationSection("tema.renkler");
        if (s != null) {
            for (String anahtar : s.getKeys(false)) {
                if (metin.contains(sadelestir(anahtar))) {
                    Color c = hex(s.getString(anahtar));
                    if (c != null) {
                        return c;
                    }
                }
            }
        }
        Color v = hex(eklenti.getConfig().getString("tema.varsayilan", "#FFFFFF"));
        return v == null ? Color.WHITE : v;
    }

    private Color hex(String h) {
        if (h == null) {
            return null;
        }
        try {
            String t = h.startsWith("#") ? h.substring(1) : h;
            return Color.fromRGB(Integer.parseInt(t, 16));
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}
