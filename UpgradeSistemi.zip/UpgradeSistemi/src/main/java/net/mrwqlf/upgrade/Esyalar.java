package net.mrwqlf.upgrade;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/** Scroll, Arcana Scroll ve Shard esyalari. Kimlik PDC'de saklanir (taklit edilemez). */
public final class Esyalar {

    public static final List<String> TURLER = List.of("scroll_1", "scroll_2", "scroll_3", "arcana", "shard_weapon_g", "shard_armor_g", "shard_weapon_e", "shard_armor_e");

    private final MiniMessage mm = MiniMessage.miniMessage();
    private final NamespacedKey tur;

    public Esyalar(UpgradeSistemi eklenti) {
        this.tur = new NamespacedKey(eklenti, "upg_tur");
    }

    public String turu(ItemStack e) {
        if (e == null || !e.hasItemMeta()) {
            return null;
        }
        String t = e.getItemMeta().getPersistentDataContainer().get(tur, PersistentDataType.STRING);
        return (t != null && TURLER.contains(t)) ? t : null;
    }

    public ItemStack uret(String t, int adet) {
        Material m = t.startsWith("shard") ? Material.AMETHYST_SHARD : Material.PAPER;
        ItemStack e = new ItemStack(m, Math.max(1, adet));
        ItemMeta meta = e.getItemMeta();
        String ad;
        List<String> lore;
        switch (t) {
            case "scroll_1" -> {
                ad = "<gray><bold>Yükseltme Scroll'u <dark_gray>[Zayıf]";
                lore = List.of("<gray>Normal silah ve zırhlar için", "<gray>(elmas, demir, netherit ve altı).", "<white>+5'e kadar <gray>yükseltir.");
            }
            case "scroll_2" -> {
                ad = "<aqua><bold>Yükseltme Scroll'u <dark_aqua>[Güçlü]";
                lore = List.of("<gray>Normal silah ve zırhlar için", "<gray>(elmas, demir, netherit ve altı).", "<white>+10'a kadar <gray>yükseltir.");
            }
            case "scroll_3" -> {
                ad = "<gold><bold>Yükseltme Scroll'u <yellow>[Efsanevi]";
                lore = List.of("<gray>Yöneticinin kaydettiği <white>özel eşyalar", "<gray>için. +10'a kadar yükseltir.");
            }
            case "arcana" -> {
                ad = "<light_purple><bold>Arcana Scroll";
                lore = List.of("<gray>Eşyaya uygulanır; <white>sonraki yükseltme", "<gray>şansını <white>2 katına <gray>çıkarır (1 kez).");
            }
            case "shard_weapon_g" -> {
                ad = "<aqua><bold>Güçlü Silah Shard'ı";
                lore = List.of("<gray>Normal silahların +6 sonrası", "<gray>yükseltmeleri için.");
            }
            case "shard_armor_g" -> {
                ad = "<aqua><bold>Güçlü Zırh Shard'ı";
                lore = List.of("<gray>Normal zırhların +6 sonrası", "<gray>yükseltmeleri için.");
            }
            case "shard_weapon_e" -> {
                ad = "<gold><bold>Efsanevi Silah Shard'ı";
                lore = List.of("<gray>Kayıtlı özel silahların +6 sonrası", "<gray>yükseltmeleri için.");
            }
            default -> {
                ad = "<gold><bold>Efsanevi Zırh Shard'ı";
                lore = List.of("<gray>Kayıtlı özel zırhların +6 sonrası", "<gray>yükseltmeleri için.");
            }
        }
        meta.displayName(mm.deserialize("<!italic>" + ad));
        List<Component> l = new java.util.ArrayList<>();
        for (String s : lore) {
            l.add(mm.deserialize("<!italic>" + s));
        }
        if (t.startsWith("scroll") || t.equals("arcana")) {
            l.add(Component.empty());
            l.add(mm.deserialize("<!italic><yellow>İmlece al ve eşyanın üstüne tıkla."));
        }
        meta.lore(l);
        meta.setItemModel(new NamespacedKey("upgrade", t));
        if (t.equals("arcana")) {
            meta.setEnchantmentGlintOverride(true);
        }
        meta.getPersistentDataContainer().set(tur, PersistentDataType.STRING, t);
        e.setItemMeta(meta);
        return e;
    }
}
