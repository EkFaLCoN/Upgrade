package net.mrwqlf.upgrade;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Demirci yukseltme ekrani. Esyalar oyuncu envanterinden ekrana TASINIR (kopyalanmaz);
 * ekran kapaninca kalanlar geri verilir. Tum tiklamalar iptal edilir.
 */
public final class UpgradeMenu {

    static final int ESYA = 11, SCROLL = 13, ARCANA = 15, DUGME = 22;

    static final class Tutucu implements InventoryHolder {
        Inventory envanter;

        @Override
        public Inventory getInventory() {
            return envanter;
        }
    }

    private final UpgradeSistemi eklenti;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public UpgradeMenu(UpgradeSistemi eklenti) {
        this.eklenti = eklenti;
    }

    private void mesaj(Player p, String anahtar, TagResolver... c) {
        p.sendMessage(mm.deserialize(eklenti.getConfig().getString("mesajlar." + anahtar, anahtar), c));
    }

    private ItemStack dugme(Material m, String ad, List<String> lore) {
        ItemStack e = new ItemStack(m);
        var meta = e.getItemMeta();
        meta.displayName(mm.deserialize("<!italic>" + ad));
        List<Component> l = new ArrayList<>();
        for (String s : lore) {
            l.add(mm.deserialize("<!italic>" + s));
        }
        meta.lore(l);
        e.setItemMeta(meta);
        return e;
    }

    private ItemStack dolgu() {
        ItemStack d = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        var meta = d.getItemMeta();
        meta.displayName(Component.empty());
        d.setItemMeta(meta);
        return d;
    }

    private boolean bos(ItemStack e) {
        return e == null || e.getType().isAir();
    }

    // ---------------------------------------------------------------- acma / kapama

    public void ac(Player p) {
        Tutucu t = new Tutucu();
        t.envanter = Bukkit.createInventory(t, 27, mm.deserialize("<dark_gray>Demirci • Yükseltme"));
        yenile(p, t);
        p.openInventory(t.envanter);
    }

    public static boolean bizimMi(Inventory env) {
        return env != null && env.getHolder() instanceof Tutucu;
    }

    /** Kapaninca icerideki esyalari oyuncuya geri verir. */
    public void kapandi(Player p, Inventory env) {
        for (int slot : new int[]{ESYA, SCROLL, ARCANA}) {
            ItemStack e = env.getItem(slot);
            if (!bos(e)) {
                env.setItem(slot, null);
                ver(p, e);
            }
        }
    }

    private void ver(Player p, ItemStack e) {
        for (ItemStack artan : p.getInventory().addItem(e).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), artan);
        }
    }

    // ---------------------------------------------------------------- tiklama

    public void tikla(Player p, Inventory env, boolean ust, int slot) {
        Tutucu t = (Tutucu) env.getHolder();
        if (ust) {
            if (slot == ESYA || slot == SCROLL || slot == ARCANA) {
                ItemStack e = env.getItem(slot);
                if (!bos(e)) {
                    env.setItem(slot, null);
                    ver(p, e);
                    yenile(p, t);
                }
            } else if (slot == DUGME) {
                yukselt(p, t);
            }
            return;
        }
        // Oyuncu envanteri: tiklanan esyayi ilgili yuvaya TASI (1 adet)
        ItemStack kaynak = p.getInventory().getItem(slot);
        if (bos(kaynak)) {
            return;
        }
        String tur = eklenti.esyalar().turu(kaynak);
        int hedef;
        if (tur != null && tur.startsWith("scroll_")) {
            hedef = SCROLL;
        } else if ("arcana".equals(tur)) {
            hedef = ARCANA;
        } else if (tur == null && (Seviye.silahMi(kaynak) || Seviye.zirhMi(kaynak))) {
            hedef = ESYA;
        } else {
            mesaj(p, "gecersiz-esya");
            return;
        }
        if (!bos(env.getItem(hedef))) {
            mesaj(p, "yuva-dolu");
            return;
        }
        ItemStack tasinan = kaynak.clone();
        tasinan.setAmount(1);
        if (kaynak.getAmount() <= 1) {
            p.getInventory().setItem(slot, null);
        } else {
            ItemStack kalan = kaynak.clone();
            kalan.setAmount(kaynak.getAmount() - 1);
            p.getInventory().setItem(slot, kalan);
        }
        env.setItem(hedef, tasinan);
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.3f);
        yenile(p, t);
    }

    // ---------------------------------------------------------------- gorunum

    private void yenile(Player p, Tutucu t) {
        Inventory env = t.envanter;
        for (int i = 0; i < env.getSize(); i++) {
            if (i != ESYA && i != SCROLL && i != ARCANA) {
                env.setItem(i, dolgu());
            }
        }
        if (bos(env.getItem(ESYA))) {
            env.setItem(ESYA, dugme(Material.IRON_SWORD, "<white>Eşya yuvası",
                    List.of("<gray>Envanterindeki silah/zırha tıkla.")));
        }
        if (bos(env.getItem(SCROLL))) {
            env.setItem(SCROLL, dugme(Material.PAPER, "<white>Scroll yuvası",
                    List.of("<gray>Envanterindeki scroll'a tıkla.")));
        }
        if (bos(env.getItem(ARCANA))) {
            env.setItem(ARCANA, dugme(Material.AMETHYST_SHARD, "<light_purple>Arcana yuvası <gray>(isteğe bağlı)",
                    List.of("<gray>Şansı artırır; denemede harcanır.")));
        }
        env.setItem(DUGME, dugmeOlustur(p, env));
    }

    private ItemStack esya(Inventory env) {
        ItemStack e = env.getItem(ESYA);
        return !bos(e) && (Seviye.silahMi(e) || Seviye.zirhMi(e)) ? e : null;
    }

    private ItemStack scroll(Inventory env) {
        ItemStack e = env.getItem(SCROLL);
        String tur = bos(e) ? null : eklenti.esyalar().turu(e);
        return tur != null && tur.startsWith("scroll_") ? e : null;
    }

    private ItemStack arcana(Inventory env) {
        ItemStack e = env.getItem(ARCANA);
        return !bos(e) && "arcana".equals(eklenti.esyalar().turu(e)) ? e : null;
    }

    /** Dogrulama sonucu: hata mesaj anahtari ya da null. */
    private String kontrol(Player p, Inventory env, long[] ucretCikis, int[] shardCikis, String[] shardTurCikis) {
        ItemStack hedef = esya(env);
        ItemStack sc = scroll(env);
        if (hedef == null || sc == null) {
            return "eksik";
        }
        Seviye sv = eklenti.seviye();
        boolean silah = Seviye.silahMi(hedef);
        int seviye = sv.seviye(hedef);
        if (seviye >= Seviye.MAKS) {
            return "maksimum";
        }
        int olcek = Integer.parseInt(eklenti.esyalar().turu(sc).substring("scroll_".length()));
        boolean kayitli = eklenti.kayit().kayitli(hedef);
        if (kayitli && olcek != 3) {
            return "kayitli-esya";
        }
        if (!kayitli && olcek == 3) {
            return "efsanevi-kayitsiz";
        }
        if (!kayitli && eklenti.kayit().ozelMi(hedef)) {
            return "ozel-kayitsiz";
        }
        int hedefSeviye = seviye + 1;
        int zayifMaks = eklenti.getConfig().getInt("scroll.zayif-hedef-maks", 5);
        if (olcek == 1 && hedefSeviye > zayifMaks) {
            return "scroll-zayif";
        }
        shardCikis[0] = sv.shardGerek(hedefSeviye);
        shardTurCikis[0] = (silah ? "shard_weapon" : "shard_armor") + (kayitli ? "_e" : "_g");
        ucretCikis[0] = 0;
        if (eklenti.getConfig().getBoolean("para.aktif", true)) {
            ucretCikis[0] = ucret(hedefSeviye, kayitli);
        }
        return null;
    }

    private ItemStack dugmeOlustur(Player p, Inventory env) {
        long[] ucret = new long[1];
        int[] shard = new int[1];
        String[] shardTur = new String[1];
        String hata = kontrol(p, env, ucret, shard, shardTur);
        if (hata != null) {
            String metin = hata.equals("eksik") ? "<gray>Bir eşya ve bir scroll koy."
                    : mm.stripTags(eklenti.getConfig().getString("mesajlar." + hata, hata))
                    .replace("<maks>", String.valueOf(eklenti.getConfig().getInt("scroll.zayif-hedef-maks", 5)));
            return dugme(Material.ANVIL, "<red>Yükseltilemez", List.of("<gray>" + metin));
        }
        Seviye sv = eklenti.seviye();
        ItemStack hedef = esya(env);
        int seviye = sv.seviye(hedef);
        int hs = seviye + 1;
        boolean arc = arcana(env) != null || sv.arcanaVar(hedef);
        double sans = Math.min(100.0, sv.sans(hs) * (arc ? eklenti.getConfig().getDouble("arcana-carpan", 2.0) : 1.0));
        List<String> l = new ArrayList<>();
        l.add("<gray>+" + seviye + " <white>→ <gold>+" + hs);
        l.add("<gray>Başarı şansı: <green>%" + fmt(sans) + (arc ? " <light_purple>(Arcana)" : ""));
        l.add("<gray>Kırılma (başarısızsa): <red>%" + fmt(sv.kirilma(hs)));
        if (shard[0] > 0) {
            int var = shardSay(p, shardTur[0]);
            l.add("<gray>Shard: " + (var >= shard[0] ? "<green>" : "<red>") + var + "<gray>/" + shard[0]);
        }
        if (ucret[0] > 0) {
            l.add("<gray>Ücret: <yellow>" + paraBicim(ucret[0]));
        }
        l.add("");
        l.add("<yellow>Tıkla: yükselt");
        return dugme(Material.SMITHING_TABLE, "<green>Yükselt", l);
    }

    private String fmt(double d) {
        return d == Math.floor(d) ? String.valueOf((long) d) : String.format(java.util.Locale.ROOT, "%.1f", d);
    }

    // ---------------------------------------------------------------- yukseltme

    private void yukselt(Player p, Tutucu t) {
        Inventory env = t.envanter;
        long[] ucret = new long[1];
        int[] shard = new int[1];
        String[] shardTur = new String[1];
        String hata = kontrol(p, env, ucret, shard, shardTur);
        if (hata != null) {
            if (!hata.equals("eksik")) {
                mesaj(p, hata, Placeholder.unparsed("maks",
                        String.valueOf(eklenti.getConfig().getInt("scroll.zayif-hedef-maks", 5))));
            }
            return;
        }
        Seviye sv = eklenti.seviye();
        ItemStack hedef = env.getItem(ESYA);
        boolean silah = Seviye.silahMi(hedef);
        boolean kayitli = eklenti.kayit().kayitli(hedef);
        int seviye = sv.seviye(hedef);
        int hs = seviye + 1;
        if (shard[0] > 0 && shardSay(p, shardTur[0]) < shard[0]) {
            mesaj(p, "shard-yok", Placeholder.unparsed("adet", String.valueOf(shard[0])),
                    Placeholder.unparsed("shard", (kayitli ? "Efsanevi " : "Güçlü ")
                            + (silah ? "Silah Shard'ı" : "Zırh Shard'ı")));
            return;
        }
        if (ucret[0] > 0) {
            if (!eklenti.ekonomi().var()) {
                mesaj(p, "ekonomi-yok");
                return;
            }
            if (eklenti.ekonomi().bakiye(p) < ucret[0] || !eklenti.ekonomi().cek(p, ucret[0])) {
                mesaj(p, "para-yok", Placeholder.unparsed("tutar", paraBicim(ucret[0])));
                return;
            }
        }
        // Harcamalar: scroll, arcana (yuvadan), shard (envanterden)
        boolean arc = arcana(env) != null || sv.arcanaVar(hedef);
        env.setItem(SCROLL, null);
        env.setItem(ARCANA, null);
        if (shard[0] > 0) {
            shardAl(p, shardTur[0], shard[0]);
        }
        double sans = Math.min(100.0, sv.sans(hs) * (arc ? eklenti.getConfig().getDouble("arcana-carpan", 2.0) : 1.0));
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (r.nextDouble(100.0) < sans) {
            ItemStack yeni = hedef.clone();
            sv.uygula(yeni, hs, false);
            env.setItem(ESYA, yeni);
            p.playSound(p.getLocation(), hs >= 7 ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
            mesaj(p, "basari", Placeholder.component("esya", hedef.effectiveName()),
                    Placeholder.unparsed("seviye", String.valueOf(hs)));
        } else if (r.nextDouble(100.0) < sv.kirilma(hs)) {
            env.setItem(ESYA, null);
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 0.8f);
            mesaj(p, "kirildi");
        } else {
            if (sv.arcanaVar(hedef)) {
                ItemStack yeni = hedef.clone();
                sv.uygula(yeni, seviye, false);
                env.setItem(ESYA, yeni);
            }
            p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6f, 1.4f);
            mesaj(p, "basarisiz", Placeholder.unparsed("seviye", String.valueOf(seviye)));
        }
        yenile(p, t);
    }

    long ucret(int hedefSeviye, boolean kayitli) {
        var c = eklenti.getConfig();
        double u = c.getDouble("para.baslangic", 500) * Math.pow(c.getDouble("para.carpan", 2.0), hedefSeviye - 1);
        if (kayitli) {
            u *= c.getDouble("para.efsanevi-carpan", 2.0);
        }
        return Math.max(0, Math.round(u));
    }

    private String paraBicim(long v) {
        return java.text.NumberFormat.getIntegerInstance(java.util.Locale.forLanguageTag("tr")).format(v)
                + eklenti.getConfig().getString("para.birim", "$");
    }

    private int shardSay(Player p, String tur) {
        int n = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s != null && tur.equals(eklenti.esyalar().turu(s))) {
                n += s.getAmount();
            }
        }
        return n;
    }

    private void shardAl(Player p, String tur, int adet) {
        int kalan = adet;
        ItemStack[] icerik = p.getInventory().getStorageContents();
        for (int i = 0; i < icerik.length && kalan > 0; i++) {
            ItemStack s = icerik[i];
            if (s == null || !tur.equals(eklenti.esyalar().turu(s))) {
                continue;
            }
            int al = Math.min(kalan, s.getAmount());
            if (al == s.getAmount()) {
                icerik[i] = null;
            } else {
                s.setAmount(s.getAmount() - al);
            }
            kalan -= al;
        }
        p.getInventory().setStorageContents(icerik);
    }
}
