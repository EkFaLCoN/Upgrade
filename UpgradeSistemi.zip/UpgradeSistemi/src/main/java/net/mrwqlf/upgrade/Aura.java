package net.mrwqlf.upgrade;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/** +7 ve ustu esyalar parlar: tema renginde parcacik aurasi; +10 en parlak. */
public final class Aura implements Runnable {

    private final UpgradeSistemi eklenti;
    private final Seviye seviye;
    private final Tema tema;

    public Aura(UpgradeSistemi eklenti, Seviye seviye, Tema tema) {
        this.eklenti = eklenti;
        this.seviye = seviye;
        this.tema = tema;
    }

    @Override
    public void run() {
        if (!eklenti.getConfig().getBoolean("aura.aktif", true)) {
            return;
        }
        for (Player p : eklenti.getServer().getOnlinePlayers()) {
            if (p.isDead() || p.hasPotionEffect(PotionEffectType.INVISIBILITY)
                    || p.getScoreboardTags().contains("cv_golge")) {
                continue;
            }
            ItemStack el = p.getInventory().getItemInMainHand();
            if (Seviye.silahMi(el)) {
                int l = seviye.seviye(el);
                if (l >= 7) {
                    silahAurasi(p, l, tema.renk(el));
                }
            }
            parca(p, p.getInventory().getHelmet(), 1.75);
            parca(p, p.getInventory().getChestplate(), 1.15);
            parca(p, p.getInventory().getLeggings(), 0.6);
            parca(p, p.getInventory().getBoots(), 0.1);
        }
    }

    private void silahAurasi(Player p, int l, Color renk) {
        Location goz = p.getEyeLocation();
        Vector yon = goz.getDirection();
        Vector sag = yon.clone().crossProduct(new Vector(0, 1, 0));
        if (sag.lengthSquared() < 1.0E-4) {
            sag = new Vector(1, 0, 0);
        }
        sag.normalize();
        Location el = goz.clone().add(yon.multiply(0.6)).add(sag.multiply(0.35)).add(0, -0.45, 0);
        int adet = l - 6;                 // 7 -> 1 ... 10 -> 4
        float boyut = 0.8f + (l - 6) * 0.25f;
        var dalga = p.getWorld();
        if (l >= 10) {
            dalga.spawnParticle(Particle.DUST_COLOR_TRANSITION, el, 6, 0.18, 0.25, 0.18, 0,
                    new Particle.DustTransition(renk, Color.WHITE, 1.5f));
            dalga.spawnParticle(Particle.DUST, el, 3, 0.1, 0.4, 0.1, 0, new Particle.DustOptions(renk, 1.8f));
            dalga.spawnParticle(Particle.END_ROD, el, 1, 0.15, 0.3, 0.15, 0.01);
        } else {
            dalga.spawnParticle(Particle.DUST, el, adet, 0.12, 0.2, 0.12, 0, new Particle.DustOptions(renk, boyut));
        }
    }

    private void parca(Player p, ItemStack e, double yukseklik) {
        if (e == null || !Seviye.zirhMi(e)) {
            return;
        }
        int l = seviye.seviye(e);
        if (l < 7) {
            return;
        }
        Color renk = tema.renk(e);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int adet = l >= 10 ? 3 : (l >= 9 ? 2 : 1);
        for (int i = 0; i < adet; i++) {
            double a = r.nextDouble(Math.PI * 2);
            Location yer = p.getLocation().add(Math.cos(a) * 0.4, yukseklik + r.nextDouble(-0.2, 0.2), Math.sin(a) * 0.4);
            float boyut = l >= 10 ? 1.5f : 1.0f;
            p.getWorld().spawnParticle(Particle.DUST, yer, 1, 0, 0, 0, 0, new Particle.DustOptions(renk, boyut));
        }
        if (l >= 10 && r.nextInt(3) == 0) {
            p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, yukseklik, 0), 1, 0.3, 0.2, 0.3, 0.005);
        }
    }
}
