package net.mrwqlf.upgrade;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.ThreadLocalRandom;

public final class Dinleyici implements Listener {

    private final UpgradeSistemi eklenti;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public Dinleyici(UpgradeSistemi eklenti) {
        this.eklenti = eklenti;
    }

    private void mesaj(Player p, String anahtar, TagResolver... c) {
        p.sendMessage(mm.deserialize(eklenti.getConfig().getString("mesajlar." + anahtar, anahtar), c));
    }

    // ------------------------------------------------------------ admin katalogu

    @EventHandler(priority = EventPriority.LOWEST)
    public void katalogTikla(InventoryClickEvent olay) {
        if (!(olay.getView().getTopInventory().getHolder() instanceof AdminMenu.Tutucu tutucu)) {
            return;
        }
        olay.setCancelled(true);
        if (olay.getWhoClicked() instanceof Player p && olay.getClickedInventory() != null) {
            boolean ust = olay.getClickedInventory() == olay.getView().getTopInventory();
            eklenti.adminMenu().tikla(p, tutucu, ust, olay.getSlot(), olay.getCurrentItem(), olay.getClick());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void katalogSurukle(InventoryDragEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof AdminMenu.Tutucu) {
            olay.setCancelled(true);
        }
    }

    // ------------------------------------------------------------ scroll uygulama

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void scrollTikla(InventoryClickEvent olay) {
        if (!(olay.getWhoClicked() instanceof Player p)) {
            return;
        }
        if (olay.getClickedInventory() == null || olay.getClickedInventory() != p.getInventory()) {
            return;
        }
        ItemStack imlec = olay.getCursor();
        if (imlec == null || imlec.getType().isAir()) {
            return;
        }
        String tur = eklenti.esyalar().turu(imlec);
        if (tur == null || !(tur.startsWith("scroll_") || tur.equals("arcana"))) {
            return;
        }
        ItemStack hedef = olay.getCurrentItem();
        if (hedef == null || hedef.getType().isAir()) {
            return;
        }
        olay.setCancelled(true);
        if (olay.getClick() != ClickType.LEFT) {
            return;
        }
        boolean silah = Seviye.silahMi(hedef);
        if (!silah && !Seviye.zirhMi(hedef)) {
            mesaj(p, "gecersiz-esya");
            return;
        }
        Seviye sv = eklenti.seviye();
        int seviye = sv.seviye(hedef);
        boolean arcana = sv.arcanaVar(hedef);

        if (tur.equals("arcana")) {
            if (seviye >= Seviye.MAKS) {
                mesaj(p, "maksimum");
                return;
            }
            if (arcana) {
                mesaj(p, "arcana-zaten");
                return;
            }
            ItemStack yeni = hedef.clone();
            sv.uygula(yeni, seviye, true);
            olay.setCurrentItem(yeni);
            imleciAzalt(p, imlec);
            p.playSound(p.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1f, 1.2f);
            mesaj(p, "arcana-uygulandi");
            return;
        }

        int olcek = Integer.parseInt(tur.substring("scroll_".length()));
        if (seviye >= Seviye.MAKS) {
            mesaj(p, "maksimum");
            return;
        }
        boolean kayitli = eklenti.kayit().kayitli(hedef);
        if (kayitli && olcek != 3) {
            mesaj(p, "kayitli-esya");
            return;
        }
        if (!kayitli && olcek == 3) {
            mesaj(p, "efsanevi-kayitsiz");
            return;
        }
        if (!kayitli && eklenti.kayit().ozelMi(hedef)) {
            mesaj(p, "ozel-kayitsiz");
            return;
        }
        int hedefSeviye = seviye + 1;
        if (olcek == 1 && hedefSeviye > eklenti.getConfig().getInt("scroll.zayif-hedef-maks", 5)) {
            mesaj(p, "scroll-zayif", Placeholder.unparsed("maks", String.valueOf(eklenti.getConfig().getInt("scroll.zayif-hedef-maks", 5))));
            return;
        }
        int shard = sv.shardGerek(hedefSeviye);
        String shardTuru = (silah ? "shard_weapon" : "shard_armor") + (kayitli ? "_e" : "_g");
        String shardAd = (kayitli ? "Efsanevi " : "Güçlü ") + (silah ? "Silah Shard'ı" : "Zırh Shard'ı");
        if (shard > 0 && shardSay(p, shardTuru) < shard) {
            mesaj(p, "shard-yok", Placeholder.unparsed("adet", String.valueOf(shard)),
                    Placeholder.unparsed("shard", shardAd));
            return;
        }
        // Para: her yukseltmede katlanir (baslangic * carpan^(hedef-1))
        long ucret = 0;
        if (eklenti.getConfig().getBoolean("para.aktif", true)) {
            ucret = ucret(hedefSeviye, kayitli);
            if (ucret > 0) {
                if (!eklenti.ekonomi().var()) {
                    mesaj(p, "ekonomi-yok");
                    return;
                }
                if (eklenti.ekonomi().bakiye(p) < ucret) {
                    mesaj(p, "para-yok", Placeholder.unparsed("tutar", paraBicim(ucret)));
                    return;
                }
                if (!eklenti.ekonomi().cek(p, ucret)) {
                    mesaj(p, "para-yok", Placeholder.unparsed("tutar", paraBicim(ucret)));
                    return;
                }
            }
        }

        // Her sey tamam: scroll ve shard harcanir
        imleciAzalt(p, imlec);
        if (shard > 0) {
            shardAl(p, shardTuru, shard);
        }

        double sans = Math.min(100.0, sv.sans(hedefSeviye) * (arcana ? eklenti.getConfig().getDouble("arcana-carpan", 2.0) : 1.0));
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (r.nextDouble(100.0) < sans) {
            ItemStack yeni = hedef.clone();
            sv.uygula(yeni, hedefSeviye, false);
            olay.setCurrentItem(yeni);
            p.playSound(p.getLocation(), hedefSeviye >= 7 ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
            mesaj(p, "basari", Placeholder.component("esya", hedef.effectiveName()),
                    Placeholder.unparsed("seviye", String.valueOf(hedefSeviye)));
            return;
        }
        // Basarisiz
        if (r.nextDouble(100.0) < sv.kirilma(hedefSeviye)) {
            olay.setCurrentItem(null);
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 0.8f);
            mesaj(p, "kirildi");
        } else {
            if (arcana) {
                ItemStack yeni = hedef.clone();
                sv.uygula(yeni, seviye, false);   // arcana harcandi
                olay.setCurrentItem(yeni);
            }
            p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6f, 1.4f);
            mesaj(p, "basarisiz", Placeholder.unparsed("seviye", String.valueOf(seviye)));
        }
    }

    private long ucret(int hedefSeviye, boolean kayitli) {
        var c = eklenti.getConfig();
        double u = c.getDouble("para.baslangic", 500) * Math.pow(c.getDouble("para.carpan", 2.0), hedefSeviye - 1);
        if (kayitli) {
            u *= c.getDouble("para.efsanevi-carpan", 2.0);
        }
        return Math.max(0, Math.round(u));
    }

    private String paraBicim(long v) {
        return java.text.NumberFormat.getIntegerInstance(java.util.Locale.forLanguageTag("tr")).format(v)
                + eklenti.getConfig().getString("para.birim", "$");
    }

    private void imleciAzalt(Player p, ItemStack imlec) {
        ItemStack k = imlec.clone();
        k.setAmount(k.getAmount() - 1);
        p.setItemOnCursor(k.getAmount() <= 0 ? new ItemStack(Material.AIR) : k);
    }

    private int shardSay(Player p, String tur) {
        int n = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s != null && tur.equals(eklenti.esyalar().turu(s))) {
                n += s.getAmount();
            }
        }
        return n;
    }

    private void shardAl(Player p, String tur, int adet) {
        int kalan = adet;
        ItemStack[] icerik = p.getInventory().getStorageContents();
        for (int i = 0; i < icerik.length && kalan > 0; i++) {
            ItemStack s = icerik[i];
            if (s == null || !tur.equals(eklenti.esyalar().turu(s))) {
                continue;
            }
            int al = Math.min(kalan, s.getAmount());
            if (al == s.getAmount()) {
                icerik[i] = null;
            } else {
                s.setAmount(s.getAmount() - al);
            }
            kalan -= al;
        }
        p.getInventory().setStorageContents(icerik);
    }

    // ------------------------------------------------------------ etkiler

    /** Zirh hasar azaltma: giyilen her parcanin seviyesi toplanir. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void zirhEtkisi(EntityDamageEvent olay) {
        if (!(olay.getEntity() instanceof Player kurban)) {
            return;
        }
        double azalt = 0;
        for (ItemStack parca : kurban.getInventory().getArmorContents()) {
            if (parca != null && Seviye.zirhMi(parca)) {
                azalt += eklenti.seviye().zirhAzaltma(eklenti.seviye().seviye(parca));
            }
        }
        if (azalt > 0) {
            olay.setDamage(olay.getDamage() * (1.0 - Math.min(0.75, azalt)));
        }
    }

    /** Silah hasar bonusu: ana eldeki silahin seviyesine gore. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void silahEtkisi(EntityDamageByEntityEvent olay) {
        Player atan = null;
        if (olay.getDamager() instanceof Player p) {
            atan = p;
        } else if (olay.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player p) {
            atan = p;
        }
        if (atan == null) {
            return;
        }
        ItemStack el = atan.getInventory().getItemInMainHand();
        if (!Seviye.silahMi(el)) {
            return;
        }
        int l = eklenti.seviye().seviye(el);
        if (l > 0) {
            olay.setDamage(olay.getDamage() * (1.0 + eklenti.seviye().silahBonus(l)));
        }
    }

    // ------------------------------------------------------------ dusme

    @EventHandler
    public void olum(EntityDeathEvent olay) {
        var cfg = eklenti.getConfig();
        if (!cfg.getBoolean("drop.aktif", true) || !(olay.getEntity() instanceof Monster)
                || olay.getEntity().getKiller() == null) {
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (String tur : Esyalar.TURLER) {
            double sans = cfg.getDouble("drop." + tur, 0);
            if (sans > 0 && r.nextDouble(100.0) < sans) {
                olay.getDrops().add(eklenti.esyalar().uret(tur, 1));
            }
        }
    }
}
