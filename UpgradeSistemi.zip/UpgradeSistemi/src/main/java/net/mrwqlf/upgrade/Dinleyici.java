package net.mrwqlf.upgrade;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.ThreadLocalRandom;

public final class Dinleyici implements Listener {

    private final UpgradeSistemi eklenti;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public Dinleyici(UpgradeSistemi eklenti) {
        this.eklenti = eklenti;
    }

    private void mesaj(Player p, String anahtar, TagResolver... c) {
        p.sendMessage(mm.deserialize(eklenti.getConfig().getString("mesajlar." + anahtar, anahtar), c));
    }

    // ------------------------------------------------------------ admin katalogu

    @EventHandler(priority = EventPriority.LOWEST)
    public void katalogTikla(InventoryClickEvent olay) {
        if (!(olay.getView().getTopInventory().getHolder() instanceof AdminMenu.Tutucu tutucu)) {
            return;
        }
        olay.setCancelled(true);
        if (olay.getWhoClicked() instanceof Player p && olay.getClickedInventory() != null) {
            boolean ust = olay.getClickedInventory() == olay.getView().getTopInventory();
            eklenti.adminMenu().tikla(p, tutucu, ust, olay.getSlot(), olay.getCurrentItem(), olay.getClick());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void katalogSurukle(InventoryDragEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof AdminMenu.Tutucu) {
            olay.setCancelled(true);
        }
    }

    // ------------------------------------------------------------ demirci ekrani

    @EventHandler(priority = EventPriority.LOWEST)
    public void menuTikla(InventoryClickEvent olay) {
        if (!UpgradeMenu.bizimMi(olay.getView().getTopInventory())) {
            return;
        }
        olay.setCancelled(true);
        if (!(olay.getWhoClicked() instanceof Player p) || olay.getClickedInventory() == null) {
            return;
        }
        if (olay.getClick() != ClickType.LEFT && olay.getClick() != ClickType.RIGHT
                && olay.getClick() != ClickType.SHIFT_LEFT && olay.getClick() != ClickType.SHIFT_RIGHT) {
            return;
        }
        Inventory ust = olay.getView().getTopInventory();
        if (olay.getClickedInventory() == ust) {
            eklenti.upgradeMenu().tikla(p, ust, true, olay.getSlot());
        } else if (olay.getClickedInventory() == p.getInventory()) {
            eklenti.upgradeMenu().tikla(p, ust, false, olay.getSlot());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void menuSurukle(InventoryDragEvent olay) {
        if (UpgradeMenu.bizimMi(olay.getView().getTopInventory())) {
            olay.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void menuKapandi(InventoryCloseEvent olay) {
        if (UpgradeMenu.bizimMi(olay.getInventory()) && olay.getPlayer() instanceof Player p) {
            eklenti.upgradeMenu().kapandi(p, olay.getInventory());
        }
    }

    // ------------------------------------------------------------ demirci NPC

    private final java.util.Map<java.util.UUID, Long> npcBekleme = new java.util.HashMap<>();

    /** Hem "At" hem normal etkilesim olayinda calisir; cift acilma 400 ms bekleme ile engellenir. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void npcEtkilesim(PlayerInteractEntityEvent olay) {
        if (!eklenti.npc().npcMi(olay.getRightClicked())) {
            return;
        }
        olay.setCancelled(true);
        Player p = olay.getPlayer();
        long simdi = System.currentTimeMillis();
        Long son = npcBekleme.get(p.getUniqueId());
        if (son != null && simdi - son < 400L) {
            return;
        }
        npcBekleme.put(p.getUniqueId(), simdi);
        org.bukkit.entity.Entity npc = olay.getRightClicked();
        Bukkit.getScheduler().runTask(eklenti, () -> {
            if (!p.isOnline() || !npc.isValid()) {
                return;
            }
            if (p.isSneaking() && p.hasPermission("upgrade.admin")) {
                eklenti.npc().kaldir(p, npc);
            } else {
                eklenti.upgradeMenu().ac(p);
            }
        });
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void npcEtkilesimAt(PlayerInteractAtEntityEvent olay) {
        if (eklenti.npc().npcMi(olay.getRightClicked())) {
            olay.setCancelled(true);
        }
    }

    /** Yonetici NPC'ye Shift+sol tik ile de kaldirabilir. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void npcVurus(EntityDamageByEntityEvent olay) {
        if (!eklenti.npc().npcMi(olay.getEntity())) {
            return;
        }
        olay.setCancelled(true);
        if (olay.getDamager() instanceof Player p && p.isSneaking() && p.hasPermission("upgrade.admin")) {
            eklenti.npc().kaldir(p, olay.getEntity());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void npcHasar(EntityDamageEvent olay) {
        if (eklenti.npc().npcMi(olay.getEntity())) {
            olay.setCancelled(true);
        }
    }

    // ------------------------------------------------------------ etkiler

    /** Zirh hasar azaltma: giyilen her parcanin seviyesi toplanir. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void zirhEtkisi(EntityDamageEvent olay) {
        if (!(olay.getEntity() instanceof Player kurban)) {
            return;
        }
        double azalt = 0;
        for (ItemStack parca : kurban.getInventory().getArmorContents()) {
            if (parca != null && Seviye.zirhMi(parca)) {
                azalt += eklenti.seviye().zirhAzaltma(eklenti.seviye().seviye(parca)) * eklenti.seviye().statCarpani(parca);
            }
        }
        if (azalt > 0) {
            olay.setDamage(olay.getDamage() * (1.0 - Math.min(0.75, azalt)));
        }
    }

    /** Silah hasar bonusu: ana eldeki silahin seviyesine gore. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void silahEtkisi(EntityDamageByEntityEvent olay) {
        Player atan = null;
        if (olay.getDamager() instanceof Player p) {
            atan = p;
        } else if (olay.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player p) {
            atan = p;
        }
        if (atan == null) {
            return;
        }
        ItemStack el = atan.getInventory().getItemInMainHand();
        if (!Seviye.silahMi(el)) {
            return;
        }
        int l = eklenti.seviye().seviye(el);
        if (l > 0) {
            olay.setDamage(olay.getDamage() * (1.0 + eklenti.seviye().silahBonus(l) * eklenti.seviye().statCarpani(el)));
        }
    }

    // ------------------------------------------------------------ dusme

    @EventHandler
    public void olum(EntityDeathEvent olay) {
        var cfg = eklenti.getConfig();
        if (!cfg.getBoolean("drop.aktif", true) || !(olay.getEntity() instanceof Monster)
                || olay.getEntity().getKiller() == null) {
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (String tur : Esyalar.TURLER) {
            double sans = cfg.getDouble("drop." + tur, 0);
            if (sans > 0 && r.nextDouble(100.0) < sans) {
                olay.getDrops().add(eklenti.esyalar().uret(tur, 1));
            }
        }
    }
}
